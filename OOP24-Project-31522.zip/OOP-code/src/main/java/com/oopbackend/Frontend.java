package com.oopbackend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Frontend extends JFrame {
    private JTextArea serverResponseArea;
    private JComboBox<String> courseComboBox;
    private JComboBox<String> groupComboBox;
    private JComboBox<String> exerciseComboBox;
    private JTextField fileNameField; // Renamed from customFileNameField to fileNameField

    public Frontend() {
        super("File Transfer Client Application");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create components
        JPanel panel = new JPanel(new GridLayout(5, 2, 5, 5)); // Adjusted for 5 rows
        JLabel courseLabel = new JLabel("Course:");
        courseComboBox = new JComboBox<>(new String[]{"OOP"});
        JLabel groupLabel = new JLabel("Group:");
        groupComboBox = new JComboBox<>(new String[]{"Group1", "Group2"});
        JLabel exerciseLabel = new JLabel("Exercise:");
        exerciseComboBox = new JComboBox<>(new String[]{"Exercise01", "Exercise02"});
        JLabel fileLabel = new JLabel("File Name:");
        fileNameField = new JTextField(); // Use a text field for file name input directly

        // Add components to panel
        panel.add(courseLabel);
        panel.add(courseComboBox);
        panel.add(groupLabel);
        panel.add(groupComboBox);
        panel.add(exerciseLabel);
        panel.add(exerciseComboBox);
        panel.add(fileLabel);
        panel.add(fileNameField);

        JButton sendButton = new JButton("Download File");
        panel.add(sendButton);

        serverResponseArea = new JTextArea();
        serverResponseArea.setEditable(false);
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(serverResponseArea), BorderLayout.CENTER);

        // Action listener for the send button
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                downloadFile();
            }
        });
    }

    private void downloadFile() {
        // Get user input
        String course = (String) courseComboBox.getSelectedItem();
        String group = (String) groupComboBox.getSelectedItem();
        String exercise = (String) exerciseComboBox.getSelectedItem();
        String fileName = fileNameField.getText().trim(); // Get file name from the text field

        if (fileName.isEmpty()) {
            serverResponseArea.setText("Please enter a file name.");
            return;
        }

        // Construct the URL
        String urlString = "http://localhost:8000/host/Shared/" + course + "/" + group + "/" + exercise + "/" + fileName;

        try {
            // Create URL object
            URL url = new URL(urlString);

            // Create HttpURLConnection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set request mode to GET
            connection.setRequestMethod("GET");

            // Get response code
            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Read response from input stream
                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Check if the response contains the "File not found" message
                if (response.toString().contains("File not found in resources.")) {
                    serverResponseArea.setText("Error: File not found on server.");
                } else {
                    // Create directories if they do not exist
                    String localDir = "./src/main/resources/local/" + group + "/" + exercise;
                    File directory = new File(localDir);
                    if (!directory.exists()) {
                        directory.mkdirs();
                    }

                    // Save the file
                    File file = new File(localDir + "/" + fileName);
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    fileOutputStream.write(response.toString().getBytes());
                    fileOutputStream.close();

                    // Display success message
                    serverResponseArea.setText("File downloaded successfully to " + file.getAbsolutePath());
                }
            } else {
                serverResponseArea.setText("Failed to download file. Response code: " + responseCode);
            }

            // Disconnect the connection
            connection.disconnect();

        } catch (IOException ex) {
            // Display error message if an exception occurs
            serverResponseArea.setText("Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Frontend().setVisible(true);
            }
        });
    }
}
